#ifndef MICS6814_H
#define MICS6814_H

#include <Arduino.h>

enum gas_t {
CO,
NO2,
NH3
};

enum channel_t {
CH_CO,
CH_NO2,
CH_NH3
};

class MICS6814 {
public:
// Konstruktor untuk 3 pin analog (CO, NO2, NH3)
MICS6814(uint8_t pinCO, uint8_t pinNO2, uint8_t pinNH3)
: _pinCO(pinCO), _pinNO2(pinNO2), _pinNH3(pinNH3),
_baseCO(330), _baseNO2(330), _baseNH3(330) {} // baseline default

// Fungsi utama
float measure(gas_t gas);
uint16_t getResistance(channel_t channel) const;
uint16_t getBaseResistance(channel_t channel) const;
float getCurrentRatio(channel_t channel) const;

// Kalibrasi sederhana untuk baseline (opsional)
void calibrate() {
_baseCO = getResistance(CH_CO);
_baseNO2 = getResistance(CH_NO2);
_baseNH3 = getResistance(CH_NH3);
}

private:
uint8_t _pinCO;
uint8_t _pinNO2;
uint8_t _pinNH3;

uint16_t _baseCO;
uint16_t _baseNO2;
uint16_t _baseNH3;
};

#endif