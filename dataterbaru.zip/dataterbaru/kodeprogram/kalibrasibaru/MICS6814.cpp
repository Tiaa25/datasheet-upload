#include "mics6814.h"

/**

Fungsi utama untuk mengukur konsentrasi gas dalam ppm

Berdasarkan hasil eksperimen datasheet MICS6814.
*/
float MICS6814::measure(gas_t gas)
{
float ratio;
float c = 0;

switch (gas)
{
case CO:
ratio = getCurrentRatio(CH_CO);
c = pow(ratio, -1.179) * 4.385; // persamaan empiris CO
break;

case NO2:
ratio = getCurrentRatio(CH_NO2);
c = pow(ratio, 1.007) / 6.855; // persamaan empiris NO2
break;

case NH3:
ratio = getCurrentRatio(CH_NH3);
c = pow(ratio, -1.67) / 1.47; // persamaan empiris NH3
break;
}

// jika hasil tak valid, kembalikan -1
return isnan(c) ? -1 : c;
}

/**

Membaca resistansi kanal analog sensor (ADC 10-bit: 0–1023)

Ditambahkan filter rata-rata agar lebih stabil.
*/
uint16_t MICS6814::getResistance(channel_t channel) const
{
unsigned long sum = 0;
const int samples = 50; // jumlah sampel untuk averaging

switch (channel)
{
case CH_CO:
for (int i = 0; i < samples; i++)
{
sum += analogRead(_pinCO);
delay(2);
}
break;

case CH_NO2:
for (int i = 0; i < samples; i++)
{
sum += analogRead(_pinNO2);
delay(2);
}
break;

case CH_NH3:
for (int i = 0; i < samples; i++)
{
sum += analogRead(_pinNH3);
delay(2);
}
break;
}

return (uint16_t)(sum / samples);
}

/**

Mengambil resistansi dasar (baseline) tiap kanal
*/
uint16_t MICS6814::getBaseResistance(channel_t channel) const
{
switch (channel)
{
case CH_CO:
return _baseCO;
case CH_NO2:
return _baseNO2;
case CH_NH3:
return _baseNH3;
default:
return 0;
}
}

/**

Menghitung rasio Rs/R0

Rasio sederhana tanpa koreksi ADC agar pembacaan lebih tinggi (lebih realistis)
*/
float MICS6814::getCurrentRatio(channel_t channel) const
{
float R0 = (float)getBaseResistance(channel);
float Rs = (float)getResistance(channel);

if (R0 <= 0 || Rs <= 0)
return 1.0;

return Rs / R0;
}